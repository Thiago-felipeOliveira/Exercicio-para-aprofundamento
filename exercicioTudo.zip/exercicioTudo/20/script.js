// Thiago Felipe de Oliveira Ribeiro
document.getElementById('fileInput').addEventListener('change', handleFileSelect);

function handleFileSelect(event) {
    const files = event.target.files;
    const previewArea = document.getElementById('previewArea');
    previewArea.innerHTML = '';

    Array.from(files).forEach(file => {
        const reader = new FileReader();

        reader.onload = function(e) {
            const imgElement = document.createElement('img');
            imgElement.src = e.target.result;
            imgElement.style.maxWidth = '200px'; 
            previewArea.appendChild(imgElement);
        };

        reader.readAsDataURL(file);
    });
}
