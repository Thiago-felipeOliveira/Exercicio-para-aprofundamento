// Thiago Felipe de Oliveira Ribeiro
document.getElementById('reservationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    var date = document.getElementById('date').value;
    var time = document.getElementById('time').value;
    
    if (date && time) {
        document.getElementById('confirmationMessage').innerHTML = `Reserva confirmada para ${date} às ${time}.`;
    } else {
        document.getElementById('confirmationMessage').innerHTML = 'Por favor, selecione uma data e uma hora.';
    }
});
