// Thiago Felipe de Oliveira Ribeiro
document.getElementById('animateButton').addEventListener('click', function() {
    const button = this;
    button.classList.remove('animate');
    void button.offsetWidth;
    button.classList.add('animate');
});
