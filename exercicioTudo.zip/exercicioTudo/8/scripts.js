// Thiago Felipe de Oliveira Ribeiro
const carouselSlide = document.querySelector('.carousel-slide');
const images = document.querySelectorAll('.carousel-slide img');

const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');

let counter = 0;
const size = images[0].clientWidth;

function showSlide(index) {
  carouselSlide.style.transform = `translateX(${-index * size}px)`;
}

function nextSlide() {
  if (counter >= images.length - 1) {
    counter = 0;
  } else {
    counter++;
  }
  showSlide(counter);
}

function prevSlide() {
  if (counter <= 0) {
    counter = images.length - 1;
  } else {
    counter--;
  }
  showSlide(counter);
}

nextBtn.addEventListener('click', nextSlide);
prevBtn.addEventListener('click', prevSlide);

let slideInterval = setInterval(nextSlide, 3000);

carouselSlide.addEventListener('mouseover', () => {
  clearInterval(slideInterval);
});

carouselSlide.addEventListener('mouseleave', () => {
  slideInterval = setInterval(nextSlide, 3000);
});
