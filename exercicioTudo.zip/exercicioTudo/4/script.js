// Thiago Felipe de Oliveira Ribeiro
function addRow() {
    var table = document.getElementById("myTable").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow();

    newRow.style.backgroundColor = "pink";
    var cell1 = newRow.insertCell(0);
    var cell2 = newRow.insertCell(1);

    cell1.innerHTML = "Nova Linha";
    cell2.innerHTML = "Nova Linha";
}
