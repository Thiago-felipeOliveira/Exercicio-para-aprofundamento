// Thiago Felipe de Oliveira Ribeiro
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var validUsername = "usuario";
    var validPassword = "senha123";

    if (username === validUsername && password === validPassword) {
        localStorage.setItem('isLoggedIn', 'true');
        window.location.href = 'dashboard.html'; 
    } else {
        document.getElementById('error-message').textContent = 'Usuário ou senha incorretos';
    }
});


window.onload = function() {
    if (localStorage.getItem('isLoggedIn') === 'true') {
        window.location.href = 'index.html'; 
    }
};

