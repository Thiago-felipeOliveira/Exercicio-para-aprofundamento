// Thiago Felipe de Oliveira Ribeiro
document.addEventListener('DOMContentLoaded', function() {
    const textInput = document.getElementById('textInput');
    const wordCountDisplay = document.getElementById('wordCount');

    textInput.addEventListener('input', function() {
        const text = textInput.value;
        
        const words = text.trim().split(/\s+/).filter(word => word.length > 0);
        wordCountDisplay.textContent = words.length;
    });
});
