// Thiago Felipe de Oliveira Ribeiro
function validarFormulario() {
    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var mensagem = document.getElementById('mensagem').value;

    if (nome === '' || email === '' || mensagem === '') {
        alert('Por favor, preencha todos os campos.');
        return false;
    }

    // Aqui você pode adicionar mais validações específicas, como o formato do e-mail
    if (!validarEmail(email)) {
        alert('Por favor, insira um e-mail válido.');
        return false;
    }

    return true;
}

function validarEmail(email) {
    var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}
