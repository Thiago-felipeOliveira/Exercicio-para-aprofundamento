// Thiago Felipe de Oliveira Ribeiro
document.addEventListener('DOMContentLoaded', function() {
    var itens = document.querySelectorAll('#minhaLista li');

    itens.forEach(function(item) {
        item.addEventListener('click', function() {
            itens.forEach(function(it) {
                it.style.backgroundColor = '';
            });
            this.style.backgroundColor = 'pink';
        });
    });
});
