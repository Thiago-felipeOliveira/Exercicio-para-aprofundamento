// Thiago Felipe de Oliveira Ribeiro
document.addEventListener('DOMContentLoaded', loadTasks);

function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';
    tasks.forEach((task, index) => {
        addTaskToDOM(task, index);
    });
}

function addTask() {
    const input = document.getElementById('new-task');
    const taskText = input.value.trim();
    if (taskText) {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        tasks.push({ text: taskText, completed: false });
        localStorage.setItem('tasks', JSON.stringify(tasks));
        input.value = ''; 
        loadTasks();
    }
}

function toggleCompletion(index) {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks[index].completed = !tasks[index].completed;
    localStorage.setItem('tasks', JSON.stringify(tasks));
    loadTasks();
}

function removeTask(index) {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.splice(index, 1);
    localStorage.setItem('tasks', JSON.stringify(tasks));
    loadTasks();
}

function addTaskToDOM(task, index) {
    const taskList = document.getElementById('task-list');
    const taskElement = document.createElement('li');
    taskElement.textContent = task.text;
    if (task.completed) {
        taskElement.classList.add('completed');
    }
    taskElement.onclick = () => toggleCompletion(index);
    const removeButton = document.createElement('button');
    removeButton.textContent = 'Remover';
    removeButton.onclick = (event) => {
        event.stopPropagation();
        removeTask(index);
    };
    taskElement.appendChild(removeButton);
    taskList.appendChild(taskElement);
}
