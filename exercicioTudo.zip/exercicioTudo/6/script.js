// Thiago Felipe de Oliveira Ribeiro
function addComment() {
    var input = document.getElementById('commentInput');
    var commentText = input.value.trim();

    if (commentText !== '') {
        var commentList = document.getElementById('commentList');
        var newComment = document.createElement('li');
        newComment.className = 'comment';
        newComment.textContent = commentText;
        commentList.appendChild(newComment);

        input.value = ''; // Limpar o campo de entrada após adicionar o comentário
    } else {
        alert('Por favor, digite um comentário antes de adicionar.');
    }
}
