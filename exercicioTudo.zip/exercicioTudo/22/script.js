// Thiago Felipe de Oliveira Ribeiro
function validateForm() {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var cardNumber = document.getElementById('cardNumber').value;
    var expiryDate = document.getElementById('expiryDate').value;
    var cvv = document.getElementById('cvv').value;


    if (!name.trim()) {
        alert('Por favor, digite seu nome completo.');
        return false;
    }

    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert('Por favor, digite um e-mail válido.');
        return false;
    }

    if (!/^\d{16}$/.test(cardNumber)) {
        alert('Por favor, digite um número de cartão válido (16 dígitos).');
        return false;
    }

    if (!/^\d{2}\/\d{2}$/.test(expiryDate)) {
        alert('Por favor, digite a data de validade no formato MM/AA.');
        return false;
    }

    if (!/^\d{3}$/.test(cvv)) {
        alert('Por favor, digite o CVV de 3 dígitos.');
        return false;
    }

    return true;
}
