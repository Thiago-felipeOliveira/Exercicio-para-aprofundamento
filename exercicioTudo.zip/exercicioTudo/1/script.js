// Thiago Felipe de Oliveira Ribeiro
function showAlert() {
    alert("Bem-vindo!Amo VocêS")
}
