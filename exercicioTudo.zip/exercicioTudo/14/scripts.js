// Thiago Felipe de Oliveira Ribeiro
function filterCategory(category) {
    const cards = document.querySelectorAll('.image-card');

    cards.forEach(card => {
        if (category === 'all' || card.getAttribute('data-category') === category) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}
