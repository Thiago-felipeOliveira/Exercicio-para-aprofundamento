// Thiago Felipe de Oliveira Ribeiro
document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault(); 

    

    Swal.fire({
        title: 'Envio com Sucesso!',
        text: 'Seu formulário foi enviado com sucesso.',
        icon: 'success',
        confirmButtonText: 'OK'
    });


});
