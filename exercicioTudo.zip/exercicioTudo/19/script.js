// Thiago Felipe de Oliveira Ribeiro
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('fileInput');
    const filePreview = document.getElementById('filePreview');

    fileInput.addEventListener('change', function() {
        filePreview.innerHTML = ''; 

        const files = Array.from(fileInput.files); 
        files.forEach(file => {
            const reader = new FileReader(); 

            reader.onload = function(event) {
                const previewItem = document.createElement('div');
                previewItem.classList.add('preview-item');

                if (file.type.startsWith('image/')) {
                    const img = document.createElement('img');
                    img.src = event.target.result;
                    previewItem.appendChild(img);
                } else {
                    const fileName = document.createElement('p');
                    fileName.textContent = file.name;
                    previewItem.appendChild(fileName);
                }

                filePreview.appendChild(previewItem);
            };

            reader.readAsDataURL(file); 
        });
    });
});